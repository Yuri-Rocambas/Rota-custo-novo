package com.rotacusto.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.format.ResolverStyle
import java.util.Base64
import java.util.Locale

private val PT_BR = Locale("pt", "BR")
private val DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT)
private val MONTH_FORMAT = DateTimeFormatter.ofPattern("MM/uuuu").withResolverStyle(ResolverStyle.STRICT)
private const val BACKUP_HEADER = "ROTACUSTO_BACKUP_V2"
private fun brl(v: Double) = NumberFormat.getCurrencyInstance(PT_BR).format(v)
private fun parseNumberOrNull(s: String): Double? {
    val x = s.trim().replace("R$", "").replace(" ", "")
    if (x.isBlank()) return 0.0
    val value = if (x.contains(',') && x.contains('.')) x.replace(".", "").replace(',', '.').toDoubleOrNull()
    else x.replace(',', '.').toDoubleOrNull()
    return value?.takeIf { it.isFinite() }
}
private fun parseNumber(s: String): Double = parseNumberOrNull(s) ?: 0.0
private fun enc(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))
private fun dec(s: String) = try { String(Base64.getDecoder().decode(s), Charsets.UTF_8) } catch (_: Exception) { "" }
private fun validDate(s: String): Boolean = try { LocalDate.parse(s.trim(), DATE_FORMAT); true } catch (_: DateTimeParseException) { false }
private fun validMonth(s: String): Boolean = try { java.time.YearMonth.parse(s.trim(), MONTH_FORMAT); true } catch (_: DateTimeParseException) { false }

data class Trip(
    val id: Long, val date: String, val origin: String, val destination: String,
    val startKm: Double, val endKm: Double, val freight: Double, val commission: Double,
    val fuel: Double, val fuelLiters: Double, val toll: Double, val food: Double, val maintenance: Double,
    val tires: Double, val parts: Double, val fines: Double, val other: Double
) {
    val km get() = endKm - startKm
    val expenses get() = fuel + toll + food + maintenance + tires + parts + fines + other
    val totalCost get() = commission + expenses
    val net get() = freight - totalCost
    val costPerKm get() = if (km > 0) totalCost / km else 0.0
    val kmPerLiter get() = if (fuelLiters > 0 && km > 0) km / fuelLiters else 0.0
    val fuelCostPerKm get() = if (km > 0) fuel / km else 0.0
}

data class Tire(val id: Long, val position: String, val brand: String, val model: String, val installKm: Double, val removeKm: Double, val cost: Double) {
    val lifeKm get() = if (removeKm > installKm) removeKm - installKm else 0.0
    val costPerKm get() = if (lifeKm > 0) cost / lifeKm else 0.0
    val inUse get() = removeKm <= 0.0
}

data class Maintenance(val id: Long, val date: String, val description: String, val km: Double, val cost: Double, val nextKm: Double)
data class Settings(val truck: String = "", val trailer: String = "", val axles: Int = 6, val commissionPercent: Double = 0.0, val commissionFixed: Double = 0.0)

class RotaViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("rotacusto", Application.MODE_PRIVATE)
    private val _trips = MutableStateFlow(loadTrips())
    val trips: StateFlow<List<Trip>> = _trips.asStateFlow()
    private val _tires = MutableStateFlow(loadTires())
    val tires: StateFlow<List<Tire>> = _tires.asStateFlow()
    private val _maintenance = MutableStateFlow(loadMaintenance())
    val maintenance: StateFlow<List<Maintenance>> = _maintenance.asStateFlow()
    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private fun loadTrips(): List<Trip> = prefs.getString("trips", "").orEmpty().lineSeqAny { p ->
        if (p.size != 17 && p.size != 16) return@lineSeqAny null
        val id = p[0].toLongOrNull()?.takeIf { it > 0 } ?: return@lineSeqAny null
        val date = dec(p[1]); val origin = dec(p[2]); val destination = dec(p[3])
        if (!validDate(date) || origin.isBlank() || destination.isBlank()) return@lineSeqAny null
        val nums = if (p.size == 17) p.drop(4).map { it.toDoubleOrNull()?.takeIf { v -> v.isFinite() } ?: return@lineSeqAny null }
        else p.drop(4).map { it.toDoubleOrNull()?.takeIf { v -> v.isFinite() } ?: return@lineSeqAny null }
        val values = if (p.size == 17) nums else listOf(nums[0], nums[1], nums[2], nums[3], nums[4], 0.0) + nums.drop(5)
        if (values.any { it < 0.0 } || values[1] < values[0]) return@lineSeqAny null
        Trip(id, date, origin, destination, values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8], values[9], values[10], values[11], values[12])
    }.distinctBy { it.id }
    private fun loadTires(): List<Tire> = prefs.getString("tires", "").orEmpty().lineSeq(7) { p ->
        val id = p[0].toLongOrNull()?.takeIf { it > 0 } ?: return@lineSeq null
        val position = dec(p[1]); val brand = dec(p[2]); val model = dec(p[3])
        val install = p[4].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return@lineSeq null
        val remove = p[5].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return@lineSeq null
        val cost = p[6].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return@lineSeq null
        if (position.isBlank() || install < 0 || remove < 0 || cost < 0 || (remove > 0 && remove < install)) return@lineSeq null
        Tire(id, position, brand, model, install, remove, cost)
    }.distinctBy { it.id }
    private fun loadMaintenance(): List<Maintenance> = prefs.getString("maintenance", "").orEmpty().lineSeq(6) { p ->
        val id = p[0].toLongOrNull()?.takeIf { it > 0 } ?: return@lineSeq null
        val date = dec(p[1]); val description = dec(p[2])
        val km = p[3].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return@lineSeq null
        val cost = p[4].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return@lineSeq null
        val next = p[5].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return@lineSeq null
        if (!validDate(date) || description.isBlank() || km < 0 || cost < 0 || (next > 0 && next < km)) return@lineSeq null
        Maintenance(id, date, description, km, cost, next)
    }.distinctBy { it.id }
    private fun loadSettings() = Settings(
        prefs.getString("truck", "").orEmpty(),
        prefs.getString("trailer", "").orEmpty(),
        prefs.getInt("axles", 6).coerceIn(1, 20),
        prefs.getString("commissionPercent", null)?.toDoubleOrNull()?.takeIf { it.isFinite() }?.coerceIn(0.0, 100.0) ?: 0.0,
        prefs.getString("commissionFixed", null)?.toDoubleOrNull()?.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0
    )

    private fun save(key: String, value: String) = prefs.edit().putString(key, value).apply()
    private fun persistTrips() = save("trips", _trips.value.joinToString("\n") { listOf(it.id, enc(it.date), enc(it.origin), enc(it.destination), it.startKm, it.endKm, it.freight, it.commission, it.fuel, it.fuelLiters, it.toll, it.food, it.maintenance, it.tires, it.parts, it.fines, it.other).joinToString("|") })
    private fun persistTires() = save("tires", _tires.value.joinToString("\n") { listOf(it.id, enc(it.position), enc(it.brand), enc(it.model), it.installKm, it.removeKm, it.cost).joinToString("|") })
    private fun persistMaintenance() = save("maintenance", _maintenance.value.joinToString("\n") { listOf(it.id, enc(it.date), enc(it.description), it.km, it.cost, it.nextKm).joinToString("|") })
    fun upsertTrip(t: Trip) { _trips.value = listOf(t) + _trips.value.filterNot { it.id == t.id }; persistTrips() }
    fun deleteTrip(id: Long) { _trips.value = _trips.value.filterNot { it.id == id }; persistTrips() }
    fun upsertTire(t: Tire) { _tires.value = listOf(t) + _tires.value.filterNot { it.id == t.id }; persistTires() }
    fun deleteTire(id: Long) { _tires.value = _tires.value.filterNot { it.id == id }; persistTires() }
    fun upsertMaintenance(m: Maintenance) { _maintenance.value = listOf(m) + _maintenance.value.filterNot { it.id == m.id }; persistMaintenance() }
    fun deleteMaintenance(id: Long) { _maintenance.value = _maintenance.value.filterNot { it.id == id }; persistMaintenance() }
    fun saveSettings(s: Settings) { val x = s.copy(axles = s.axles.coerceIn(1, 20), commissionPercent = s.commissionPercent.coerceIn(0.0, 100.0), commissionFixed = s.commissionFixed.coerceAtLeast(0.0)); _settings.value = x; prefs.edit().putString("truck", x.truck).putString("trailer", x.trailer).putInt("axles", x.axles).putString("commissionPercent", x.commissionPercent.toString()).putString("commissionFixed", x.commissionFixed.toString()).apply() }
    fun defaultCommission(freight: Double): Double { val s = _settings.value; return if (s.commissionPercent > 0.0) freight * s.commissionPercent / 100.0 else s.commissionFixed }
    fun nextTripId(): Long = (_trips.value.maxOfOrNull { it.id } ?: 0L).let { if (it == Long.MAX_VALUE) error("Limite de IDs atingido") else it + 1L }
    fun nextTireId(): Long = (_tires.value.maxOfOrNull { it.id } ?: 0L).let { if (it == Long.MAX_VALUE) error("Limite de IDs atingido") else it + 1L }
    fun nextMaintenanceId(): Long = (_maintenance.value.maxOfOrNull { it.id } ?: 0L).let { if (it == Long.MAX_VALUE) error("Limite de IDs atingido") else it + 1L }

    fun exportText(): String = buildString {
        val s = _settings.value
        appendLine(BACKUP_HEADER)
        appendLine("SETTINGS|${enc(s.truck)}|${enc(s.trailer)}|${s.axles}|${s.commissionPercent}|${s.commissionFixed}")
        _trips.value.forEach { appendLine("TRIP|${it.id}|${enc(it.date)}|${enc(it.origin)}|${enc(it.destination)}|${it.startKm}|${it.endKm}|${it.freight}|${it.commission}|${it.fuel}|${it.fuelLiters}|${it.toll}|${it.food}|${it.maintenance}|${it.tires}|${it.parts}|${it.fines}|${it.other}") }
        _tires.value.forEach { appendLine("TIRE|${it.id}|${enc(it.position)}|${enc(it.brand)}|${enc(it.model)}|${it.installKm}|${it.removeKm}|${it.cost}") }
        _maintenance.value.forEach { appendLine("MAINT|${it.id}|${enc(it.date)}|${enc(it.description)}|${it.km}|${it.cost}|${it.nextKm}") }
    }
    fun importText(text: String): Boolean {
        if (text.lineSequence().firstOrNull()?.trim() != BACKUP_HEADER) return false
        val trips = mutableListOf<Trip>()
        val tires = mutableListOf<Tire>()
        val maintenance = mutableListOf<Maintenance>()
        var importedSettings: Settings? = null
        var sawData = false
        var sawSettings = false
        val tripIds = mutableSetOf<Long>(); val tireIds = mutableSetOf<Long>(); val maintenanceIds = mutableSetOf<Long>()
        try {
            text.lineSequence().drop(1).filter { it.isNotBlank() }.forEach { line ->
                val p = line.split('|')
                when (p[0]) {
                    "SETTINGS" -> {
                        if (p.size != 6 || importedSettings != null) return false
                        val axles = p[3].toIntOrNull()?.takeIf { it in 1..20 } ?: return false
                        val percent = p[4].toDoubleOrNull()?.takeIf { it.isFinite() && it in 0.0..100.0 } ?: return false
                        val fixed = p[5].toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 } ?: return false
                        importedSettings = Settings(dec(p[1]), dec(p[2]), axles, percent, fixed)
                        sawData = true; sawSettings = true
                    }
                    "TRIP" -> {
                        if (p.size != 18) return false
                        val id=p[1].toLongOrNull()?.takeIf { it > 0 } ?: return false
                        if (!tripIds.add(id)) return false
                        if (!validDate(dec(p[2])) || dec(p[3]).isBlank() || dec(p[4]).isBlank()) return false
                        val n = p.drop(5).map { it.toDoubleOrNull()?.takeIf { v -> v.isFinite() } ?: return false }
                        if (n.size != 13 || n.any { it < 0.0 }) return false
                        val start = n[0]; val end = n[1]
                        if (end < start) return false
                        trips += Trip(id, dec(p[2]), dec(p[3]), dec(p[4]), start, end, n[2], n[3], n[4], n[5], n[6], n[7], n[8], n[9], n[10], n[11], n[12])
                        sawData = true
                    }
                    "TIRE" -> {
                        if (p.size != 8) return false
                        val id=p[1].toLongOrNull()?.takeIf { it > 0 } ?: return false; if (!tireIds.add(id)) return false; val i=p[5].toDoubleOrNull()?.takeIf{it.isFinite()} ?: return false; val r=p[6].toDoubleOrNull()?.takeIf{it.isFinite()} ?: return false; val c=p[7].toDoubleOrNull()?.takeIf{it.isFinite()} ?: return false
                        if(dec(p[2]).isBlank() || i<0||r<0||c<0||(r>0&&r<i)) return false
                        tires += Tire(id,dec(p[2]),dec(p[3]),dec(p[4]),i,r,c); sawData=true
                    }
                    "MAINT" -> {
                        if (p.size != 7) return false
                        val id=p[1].toLongOrNull()?.takeIf { it > 0 } ?: return false; if (!maintenanceIds.add(id)) return false; val k=p[4].toDoubleOrNull()?.takeIf{it.isFinite()} ?: return false; val c=p[5].toDoubleOrNull()?.takeIf{it.isFinite()} ?: return false; val n=p[6].toDoubleOrNull()?.takeIf{it.isFinite()} ?: return false
                        if(!validDate(dec(p[2]))||dec(p[3]).isBlank()||k<0||c<0||(n>0&&n<k)) return false
                        maintenance += Maintenance(id,dec(p[2]),dec(p[3]),k,c,n); sawData=true
                    }
                    else -> return false
                }
            }
        } catch (_: Exception) { return false }
        if (!sawData || !sawSettings) return false
        _trips.value = trips; _tires.value = tires; _maintenance.value = maintenance; importedSettings?.let { saveSettings(it) }; persistTrips(); persistTires(); persistMaintenance(); return true
    }
}

private inline fun <T> String.lineSeq(size: Int, crossinline f: (List<String>) -> T?): List<T> = if (isBlank()) emptyList() else split('\n').mapNotNull { line -> val p = line.split('|'); if (p.size != size) null else f(p) }
private inline fun <T> String.lineSeqAny(crossinline f: (List<String>) -> T?): List<T> = if (isBlank()) emptyList() else split('\n').mapNotNull { f(it.split('|')) }

class MainActivity : ComponentActivity() { override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(vm: RotaViewModel = viewModel()) {
    val trips by vm.trips.collectAsState(); val tires by vm.tires.collectAsState(); val maintenance by vm.maintenance.collectAsState(); var tab by remember { mutableIntStateOf(0) }
    MaterialTheme { Scaffold(topBar = { TopAppBar(title = { Text("RotaCusto") }) }, bottomBar = { NavigationBar { listOf("Resumo", "Viagens", "Relatórios", "Pneus", "Manutenção", "Config.").forEachIndexed { i, l -> NavigationBarItem(selected = i == tab, onClick = { tab = i }, icon = {}, label = { Text(l) }) } } }) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { when (tab) { 0 -> Dashboard(trips); 1 -> TripsScreen(trips, vm); 2 -> ReportsScreen(trips); 3 -> TiresScreen(tires, vm); 4 -> MaintenanceScreen(maintenance, vm); 5 -> SettingsScreen(vm) } } } }
}

@Composable private fun Dashboard(trips: List<Trip>) {
    val revenue = trips.sumOf { it.freight }; val cost = trips.sumOf { it.totalCost }; val net = trips.sumOf { it.net }; val km = trips.sumOf { it.km }; val liters = trips.sumOf { it.fuelLiters }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { Text("Painel financeiro", style = MaterialTheme.typography.headlineSmall) }; item { Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Faturamento: ${brl(revenue)}"); Text("Custo total: ${brl(cost)}"); Text("Lucro líquido: ${brl(net)}"); Text("Quilometragem: %.1f km".format(PT_BR, km)); Text("Custo médio/km: ${brl(if (km > 0) cost / km else 0.0)}"); Text("Combustível: %.2f L • Consumo: %.2f km/L".format(PT_BR, liters, if (liters > 0) km / liters else 0.0)) } } }; item { Text("Viagens cadastradas: ${trips.size}") } }
}

@Composable private fun TripsScreen(trips: List<Trip>, vm: RotaViewModel) {
    var editing by remember { mutableStateOf<Trip?>(null) }; var newTrip by remember { mutableStateOf(false) }
    Column(Modifier.padding(16.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Viagens", style = MaterialTheme.typography.headlineSmall); Button({ newTrip = true }) { Text("+ Nova") } }; Spacer(Modifier.height(8.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(trips, key = { it.id }) { t -> Card { Column(Modifier.padding(12.dp)) { Text("${t.origin} → ${t.destination}", style = MaterialTheme.typography.titleMedium); Text("${t.date} • %.1f km • Frete ${brl(t.freight)}".format(PT_BR, t.km)); Text("Comissão ${brl(t.commission)} • Custos ${brl(t.expenses)}"); Text("Líquido ${brl(t.net)} • ${brl(t.costPerKm)}/km • %.2f km/L".format(PT_BR, t.kmPerLiter)); Row { TextButton({ editing = t }) { Text("Editar") }; TextButton({ vm.deleteTrip(t.id) }) { Text("Excluir") } } } } } } }
    if (newTrip) TripDialog(null, { f -> vm.defaultCommission(f) }, { newTrip = false }, { vm.upsertTrip(it); newTrip = false }, vm::nextTripId); editing?.let { TripDialog(it, { it.commission }, { editing = null }, { vm.upsertTrip(it); editing = null }, vm::nextTripId) }
}

@Composable private fun TripDialog(existing: Trip?, defaultCommission: (Double) -> Double, onDismiss: () -> Unit, onSave: (Trip) -> Unit, nextId: () -> Long) {
    var date by remember(existing) { mutableStateOf(existing?.date ?: LocalDate.now().format(DATE_FORMAT)) }; var origin by remember(existing) { mutableStateOf(existing?.origin ?: "") }; var dest by remember(existing) { mutableStateOf(existing?.destination ?: "") }
    var start by remember(existing) { mutableStateOf(existing?.startKm?.toString() ?: "") }; var end by remember(existing) { mutableStateOf(existing?.endKm?.toString() ?: "") }; var freight by remember(existing) { mutableStateOf(existing?.freight?.toString() ?: "") }; var commission by remember(existing) { mutableStateOf(existing?.commission?.toString() ?: "") }
    var fuel by remember(existing) { mutableStateOf(existing?.fuel?.toString() ?: "") }; var liters by remember(existing) { mutableStateOf(existing?.fuelLiters?.toString() ?: "") }; var toll by remember(existing) { mutableStateOf(existing?.toll?.toString() ?: "") }; var food by remember(existing) { mutableStateOf(existing?.food?.toString() ?: "") }; var maint by remember(existing) { mutableStateOf(existing?.maintenance?.toString() ?: "") }; var tires by remember(existing) { mutableStateOf(existing?.tires?.toString() ?: "") }; var parts by remember(existing) { mutableStateOf(existing?.parts?.toString() ?: "") }; var fines by remember(existing) { mutableStateOf(existing?.fines?.toString() ?: "") }; var other by remember(existing) { mutableStateOf(existing?.other?.toString() ?: "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Nova viagem" else "Editar viagem") }, text = { LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) { item { Txt(date,{date=it},"Data (dd/MM/yyyy)") }; item { Txt(origin,{origin=it},"Origem") }; item { Txt(dest,{dest=it},"Destino") }; item { Txt(start,{start=it},"Km inicial",true) }; item { Txt(end,{end=it},"Km final",true) }; item { Txt(freight,{freight=it},"Frete (R$)",true) }; item { Txt(commission,{commission=it},"Comissão (R$) — vazio usa a padrão",true) }; item { Txt(fuel,{fuel=it},"Combustível (R$)",true) }; item { Txt(liters,{liters=it},"Litros abastecidos",true) }; item { Txt(toll,{toll=it},"Pedágio (R$)",true) }; item { Txt(food,{food=it},"Alimentação (R$)",true) }; item { Txt(maint,{maint=it},"Manutenção (R$)",true) }; item { Txt(tires,{tires=it},"Pneus (R$)",true) }; item { Txt(parts,{parts=it},"Peças (R$)",true) }; item { Txt(fines,{fines=it},"Multas (R$)",true) }; item { Txt(other,{other=it},"Outros (R$)",true) } } }, confirmButton = { Button({ val parsed=listOf(start,end,freight,fuel,liters,commission,toll,food,maint,tires,parts,fines,other).map(::parseNumberOrNull); if(!validDate(date)||origin.isBlank()||dest.isBlank()||parsed.any{it==null||it<0}) return@Button; val s=parsed[0]!!; val e=parsed[1]!!; val f=parsed[2]!!; val fu=parsed[3]!!; val l=parsed[4]!!; val c=if(commission.isBlank()) defaultCommission(f) else parsed[5]!!; if(e<s||!c.isFinite()||c<0) return@Button; onSave(Trip(existing?.id?:nextId(),date.trim(),origin.trim(),dest.trim(),s,e,f,c,fu,l,parsed[6]!!,parsed[7]!!,parsed[8]!!,parsed[9]!!,parsed[10]!!,parsed[11]!!,parsed[12]!!)); onDismiss() }) { Text("Salvar") } }, dismissButton = { TextButton(onDismiss) { Text("Cancelar") } })
}

@Composable private fun Txt(v:String,set:(String)->Unit,label:String,num:Boolean=false)=OutlinedTextField(v,set,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth(),keyboardOptions=if(num) KeyboardOptions(keyboardType=KeyboardType.Decimal) else KeyboardOptions.Default)

@Composable private fun ReportsScreen(trips: List<Trip>) {
    var mode by remember { mutableIntStateOf(0) }; var date by remember { mutableStateOf(LocalDate.now().format(DATE_FORMAT)) }; var month by remember { mutableStateOf(LocalDate.now().format(MONTH_FORMAT)) }; var selectedId by remember { mutableStateOf<Long?>(null) }
    val filtered = when(mode){0->trips.filter{it.date==date.trim()};1->trips.filter{it.date.endsWith("/${month.trim()}")};else->selectedId?.let{id->trips.filter{it.id==id}}?:emptyList()}; val revenue=filtered.sumOf{it.freight}; val cost=filtered.sumOf{it.totalCost}; val net=filtered.sumOf{it.net}; val km=filtered.sumOf{it.km}; val liters=filtered.sumOf{it.fuelLiters}
    LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){ item{Text("Relatórios",style=MaterialTheme.typography.headlineSmall)}; item{Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){Button({mode=0}){Text("Dia")};Button({mode=1}){Text("Mês")};Button({mode=2}){Text("Viagem")}}}; if(mode==0)item{Txt(date,{date=it},"Data (dd/MM/yyyy)")}; if(mode==1)item{Txt(month,{month=it},"Mês (MM/yyyy)")}; if(mode==2)item{Text("Selecione uma viagem:"); trips.forEach{t->TextButton({selectedId=t.id}){Text("${t.date} — ${t.origin} → ${t.destination}")}}}; item{Card{Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text("Viagens: ${filtered.size}");Text("Faturamento: ${brl(revenue)}");Text("Custo: ${brl(cost)}");Text("Lucro líquido: ${brl(net)}");Text("Km: %.1f".format(PT_BR,km));Text("Litros: %.2f".format(PT_BR,liters));Text("Consumo: %.2f km/L".format(PT_BR,if(liters>0)km/liters else 0.0));Text("Combustível/km: ${brl(if(km>0)filtered.sumOf{it.fuel}/km else 0.0)}")}}}; items(filtered){t->Text("${t.date}: ${t.origin} → ${t.destination} | líquido ${brl(t.net)}")}}
}

@Composable private fun TiresScreen(list: List<Tire>, vm: RotaViewModel) { var editing by remember{mutableStateOf<Tire?>(null)}; var newTire by remember{mutableStateOf(false)}; Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Controle de pneus",style=MaterialTheme.typography.headlineSmall);Button({newTire=true}){Text("+ Pneu")}};Spacer(Modifier.height(8.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(list,key={it.id}){t->Card{Column(Modifier.padding(12.dp)){Text("${t.position} • ${t.brand} ${t.model}");Text("Instalação: %.0f km • ${if(t.inUse)"Em uso" else "Retirada: %.0f km".format(PT_BR,t.removeKm)}".format(PT_BR,t.installKm));Text("Vida útil: ${if(t.lifeKm>0)"%.0f km".format(PT_BR,t.lifeKm) else "em uso"} • Custo/km: ${if(t.costPerKm>0)brl(t.costPerKm) else "—"}");Row{TextButton({editing=t}){Text("Editar")};TextButton({vm.deleteTire(t.id)}){Text("Excluir")}}}}}}};if(newTire)TireDialog(null,{newTire=false},{vm.upsertTire(it);newTire=false},vm::nextTireId);editing?.let{TireDialog(it,{editing=null},{vm.upsertTire(it);editing=null},vm::nextTireId)}}
@Composable private fun TireDialog(existing:Tire?,onDismiss:()->Unit,onSave:(Tire)->Unit,nextId:()->Long){var pos by remember(existing){mutableStateOf(existing?.position?:"")};var brand by remember(existing){mutableStateOf(existing?.brand?:"")};var model by remember(existing){mutableStateOf(existing?.model?:"")};var ins by remember(existing){mutableStateOf(existing?.installKm?.toString()?:"")};var rem by remember(existing){mutableStateOf(existing?.removeKm?.toString()?:"")};var cost by remember(existing){mutableStateOf(existing?.cost?.toString()?:"")};AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Cadastrar pneu" else "Editar pneu")},text={Column(verticalArrangement=Arrangement.spacedBy(5.dp)){Txt(pos,{pos=it},"Eixo/posição");Txt(brand,{brand=it},"Marca");Txt(model,{model=it},"Modelo");Txt(ins,{ins=it},"Km de instalação",true);Txt(rem,{rem=it},"Km de retirada (0 = em uso)",true);Txt(cost,{cost=it},"Custo (R$)",true)}},confirmButton={Button({val i=parseNumberOrNull(ins);val r=parseNumberOrNull(rem);val c=parseNumberOrNull(cost);if(pos.isBlank()||i==null||r==null||c==null||i<0||(r>0&&r<i)||c<0)return@Button;onSave(Tire(existing?.id?:nextId(),pos.trim(),brand.trim(),model.trim(),i,r,c));onDismiss()}){Text("Salvar")}},dismissButton={TextButton(onDismiss){Text("Cancelar")}})}

@Composable private fun MaintenanceScreen(list:List<Maintenance>,vm:RotaViewModel){var editing by remember{mutableStateOf<Maintenance?>(null)};var newItem by remember{mutableStateOf(false)};Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Manutenção",style=MaterialTheme.typography.headlineSmall);Button({newItem=true}){Text("+ Manutenção")}};Spacer(Modifier.height(8.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(list,key={it.id}){m->Card{Column(Modifier.padding(12.dp)){Text(m.description,style=MaterialTheme.typography.titleMedium);Text("${m.date} • Km ${m.km.toInt()} • ${brl(m.cost)}");Text(if(m.nextKm>0)"Próxima revisão: km ${m.nextKm.toInt()}" else "Próxima revisão não informada");Row{TextButton({editing=m}){Text("Editar")};TextButton({vm.deleteMaintenance(m.id)}){Text("Excluir")}}}}}}};if(newItem)MaintenanceDialog(null,{newItem=false},{vm.upsertMaintenance(it);newItem=false},vm::nextMaintenanceId);editing?.let{MaintenanceDialog(it,{editing=null},{vm.upsertMaintenance(it);editing=null},vm::nextMaintenanceId)}}
@Composable private fun MaintenanceDialog(existing:Maintenance?,onDismiss:()->Unit,onSave:(Maintenance)->Unit,nextId:()->Long){var date by remember(existing){mutableStateOf(existing?.date?:LocalDate.now().format(DATE_FORMAT))};var desc by remember(existing){mutableStateOf(existing?.description?:"")};var km by remember(existing){mutableStateOf(existing?.km?.toString()?:"")};var cost by remember(existing){mutableStateOf(existing?.cost?.toString()?:"")};var next by remember(existing){mutableStateOf(existing?.nextKm?.toString()?:"")};AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Registrar manutenção" else "Editar manutenção")},text={Column(verticalArrangement=Arrangement.spacedBy(5.dp)){Txt(date,{date=it},"Data (dd/MM/yyyy)");Txt(desc,{desc=it},"Serviço");Txt(km,{km=it},"Km",true);Txt(cost,{cost=it},"Custo (R$)",true);Txt(next,{next=it},"Próxima revisão em km",true)}},confirmButton={Button({val k=parseNumberOrNull(km);val c=parseNumberOrNull(cost);val n=parseNumberOrNull(next);if(!validDate(date)||desc.isBlank()||k==null||c==null||n==null||k<0||c<0||(n>0&&n<k))return@Button;onSave(Maintenance(existing?.id?:nextId(),date.trim(),desc.trim(),k,c,n));onDismiss()}){Text("Salvar")}},dismissButton={TextButton(onDismiss){Text("Cancelar")}})}

@Composable private fun SettingsScreen(vm:RotaViewModel){val current by vm.settings.collectAsState();var truck by remember(current){mutableStateOf(current.truck)};var trailer by remember(current){mutableStateOf(current.trailer)};var axles by remember(current){mutableStateOf(current.axles.toString())};var pct by remember(current){mutableStateOf(current.commissionPercent.toString())};var fixed by remember(current){mutableStateOf(current.commissionFixed.toString())};val context=LocalContext.current;var message by remember{mutableStateOf("")};val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){message=try{val text=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:"";if(vm.importText(text))"Backup restaurado com sucesso." else "Arquivo de backup inválido."}catch(_:Exception){"Não foi possível restaurar o backup."}}};Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Configuração",style=MaterialTheme.typography.headlineSmall);Txt(truck,{truck=it},"Caminhão");Txt(trailer,{trailer=it},"Carreta");Txt(axles,{axles=it.filter(Char::isDigit)},"Quantidade de eixos",true);Txt(pct,{pct=it},"Comissão padrão (%) — use 0 para não usar",true);Txt(fixed,{fixed=it},"Comissão fixa padrão (R$) — use 0 para não usar",true);Button({val p=parseNumberOrNull(pct);val f=parseNumberOrNull(fixed);val a=axles.toIntOrNull();if(p!=null&&f!=null&&a!=null&&a in 1..20&&p in 0.0..100.0&&f>=0){vm.saveSettings(Settings(truck.trim(),trailer.trim(),a,p,f));message="Configuração salva com sucesso."}else{message="Confira os campos: eixos de 1 a 20, comissão entre 0 e 100% e comissão fixa não negativa."}}){Text("Salvar configuração")};Text("Na viagem, o percentual tem prioridade; se for 0%, usa-se a comissão fixa.");Button({shareText(context,vm.exportText())}){Text("Exportar backup")};Button({importLauncher.launch(arrayOf("text/plain","application/octet-stream"))}){Text("Restaurar backup")};if(message.isNotBlank())Text(message)} }
private fun shareText(context:Context,text:String){val send=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)};context.startActivity(Intent.createChooser(send,"Exportar RotaCusto"))}
