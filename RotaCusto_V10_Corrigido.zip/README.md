# RotaCusto

Aplicativo Android nativo em Kotlin + Jetpack Compose para controle de viagens, custos, combustível, pneus, manutenção e relatórios.

## Recursos
- Viagens com origem, destino, data, km inicial/final e frete.
- Comissão percentual ou fixa, com prioridade configurável.
- Custos por viagem: combustível, pedágio, alimentação, manutenção, pneus, peças, multas e outros.
- Litros abastecidos, consumo em km/L e custo de combustível por km.
- Relatórios por dia, mês e viagem.
- Controle de pneus com posição, instalação, retirada, vida útil e custo/km.
- Manutenção com data, km, custo e próxima revisão.
- Backup completo exportável e restauração/importação.
- Persistência local e funcionamento offline.

## Build na nuvem
O workflow `.github/workflows/android-apk.yml` compila um APK debug no GitHub Actions usando Java 17, Gradle 8.9 e Android SDK 35.

Esta versão recebeu uma revisão adicional de validação de backup e feedback ao salvar configurações. A importação agora rejeita configurações fora dos limites válidos em vez de ajustá-las silenciosamente, e a validação numérica das viagens foi simplificada. O projeto contém workflow do GitHub Actions para tentar compilar um APK debug. A compilação real do APK não foi executada neste ambiente, portanto o artefato final ainda precisa ser gerado para confirmar que não há erros de compilação.
